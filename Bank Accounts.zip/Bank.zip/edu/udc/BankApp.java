/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.udc;

import edu.udc.bank.AcctInterface;
import edu.udc.bank.BankInterface;
import java.util.Collections;


/**
 *
 * @author yeman
 */
public class BankApp {
    
    public static void main(String [] args)

    {                
           
         try {
             //Instantiating BigBank 
                BankInterface myBank = new BigBank();

                //Getting the array of AcctInterface from BigBank
                AcctInterface[] accts =  myBank.getAcctsArray();
                
                //Passing the array from above to the showTop below

                java.util.List<AcctInterface> lstAcct = BigBank.showTop(6, accts );

                //Outputing the name of the bank 
                   System.out.println("Bank Name: " + myBank.getBankName());
                
                   // sorting the returned array
                  Collections.sort(lstAcct, new Comparing());
                  
                    //Iterating through the returned List and outputing the names and balances for each account
                    for(AcctInterface ai :lstAcct)
                    {
                               System.out.println("-> " + ai.getAcctHolder() + " has a total balance of $" + ai.getAcctValue());
                    }
              }
         catch (Exception ex){
            System.out.println( ex.getMessage());
         }    
     }
    
}
