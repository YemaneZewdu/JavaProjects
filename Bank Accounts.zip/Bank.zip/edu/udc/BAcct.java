/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.udc;

import edu.udc.bank.AcctInterface;

/**
 *
 * @author yeman
 */
public class BAcct implements  AcctInterface{
    String AccHolder, ID; // string variales for holding Account Holder and Account ID
    double AccValue;        // holds Account Value
     
    // constructor for initializing the varibales
    BAcct(String ah, String ID, double AV){
        AccHolder = ah;
        this.ID = ID;
        AccValue = AV;
     }
    
    // overridding the getAcctHolder() method from AcctInterface.java
    @Override
    public String getAcctHolder(){
        return AccHolder;
    }
    
    // overridding the getUniqueID() method from AcctInterface.java
    @Override
    public String getUniqueID(){
       return ID; 
    }
    // overridding the getAcctValue() method from AcctInterface.java
    @Override
    public double getAcctValue(){
        return AccValue;
    }
    // toString method returning a nice output of ID, Account Holder, and Account value
    public String toString(){
        return "\nAccount ID \"" + ID +"\"" + " belongs to " + AccHolder + " with total balance of" + " $" + AccValue;
    }
}
