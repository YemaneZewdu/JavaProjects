/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.udc;


import edu.udc.bank.AcctInterface;
import edu.udc.bank.BankInterface;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


/**
 *
 * @author yeman
 */
public class BigBank extends UDCStudentUnion implements BankInterface {
    private String BName;  // variable for holding bank name 
    
      
        // default constructor
    public BigBank() {
        BName = "Bofa"; 
    }   
    
    // overridding the getAcctsArray() method from BankInterface.java
    @Override
     public AcctInterface[] getAcctsArray(){        
        return super.getStudentAccts();  
     }
     
     // overridding the getBankName() method from BankInterface.java
     @Override
     public String getBankName(){
         return BName;
     }
      
     public static List<AcctInterface> showTop(int howMany, AcctInterface [] aAr){
        // ArrayList for holding list of names 
         ArrayList<AcctInterface> AI = new ArrayList<> ();
                        for (int i=0; i< aAr.length; i++){
                            AI.add(aAr[i]);
                        }
                // checking for points that can break the program
             if (howMany < 0){
                 throw new RuntimeException("Negative number can't be entered!");
                } 
              if (howMany == 0){
                 throw new RuntimeException("Enter a number greater than 0!");
                } 
              else {
                  System.out.println("---- RETURNING TOP " + howMany + " ACCOUNTS ----\n");
                 }
              ArrayList<AcctInterface> sortedAI = new ArrayList<> ();
                Comparing comp  = new Comparing();
               
                Collections.sort(AI,comp); // sorting 
                
              // adding 'howMany' of the top accounts on the list
            for (int i=0; i < howMany; i++)
                {
                 sortedAI.add(AI.get(i));
                }
           
                 return sortedAI;
     }
}
