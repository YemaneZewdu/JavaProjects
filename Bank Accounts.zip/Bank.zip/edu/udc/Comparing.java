/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.udc;

import edu.udc.bank.AcctInterface;
import java.util.Comparator;


/**
 *
 * @author yeman
 */
public class Comparing implements Comparator<AcctInterface> {

   // overriding the compare class from the Comparator Interface       
    @Override
    public int compare(AcctInterface o1, AcctInterface o2) {
          int accNames = o1.getAcctHolder().compareTo(o2.getAcctHolder());
          
          
           if (accNames != 0){
              return accNames ;
          }
       else {
                //if the names are the same, compare with their account value
                Integer acc$1 = (int) o1.getAcctValue();
                Integer acc$2 = (int) o2.getAcctValue();
                return acc$1.compareTo(acc$2);
         }
   }
   
}
